//
//  AppDelegate.swift
//  AdTonosVastPlayerSampleApp
//
//  Created by Mateusz Wojnar on 10/12/2021.
//

import UIKit
import AdTonosVastPlayer

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window:UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        //Initialize with launchOptions
        AdTonosSDK.shared.intialize(with: launchOptions)

        self.window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()
        window?.makeKeyAndVisible()

        return true
    }
}

