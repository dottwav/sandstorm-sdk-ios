//
//  VastPlayerViewController.swift
//  AdTonosVastPlayerSampleApp
//
//  Created by Mateusz Wojnar on 06/12/2021.
//

import UIKit
import AdTonosVastPlayer

class VastPlayerViewController: UIViewController {

    @IBOutlet weak var statusButton: UILabel!
    private let adTonos = AdTonosSDK.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        //App should be in active state to start due to IDFA permission.
        NotificationCenter.default.addObserver(self, selector: #selector(startAdTonos), name: UIApplication.didBecomeActiveNotification, object: nil)
        //Add an observer to be notified for related callbacks.
        adTonos.add(observer: self)
    }

    @objc private func startAdTonos(){
        //Start AdTonosSDK with all consents if it is not started.
        if !AdTonosSDK.shared.isStarted {
            AdTonosSDK.shared.start(with: .allowAll)
        }
    }

    private func requestForAds(){
        guard adTonos.isStarted else {
            statusButton.text = "adTonos is not yet started"
            return
        }

        guard !adTonos.isAdAvailable else {
            statusButton.text = "The ad was already prepared"
            return
        }

        //Creates builder instance for further usage.
        let builder = adTonos.createBuilder()
            .set(adTonosKey: "KT267qyGPudAugiSt") //Sets developer key.
            .set(lang: "en") //Sets user language if different than a system defined

        statusButton.text = "Requesting ads..."
        //Requests ads to be loaded for playing
        _ = adTonos.requestForAds(with: builder)
    }

    @IBAction func requestForAds(_ sender: Any) {
        requestForAds()
    }

    @IBAction func play(_ sender: Any) {
        if adTonos.isAdAvailable {
            _ = adTonos.playAd()
        }
    }

    @IBAction func pause(_ sender: Any) {
        if adTonos.isAdAvailable {
            _ = adTonos.pauseAd()
        }
    }

    deinit {
        adTonos.clear()
        adTonos.remove(observer: self)
        NotificationCenter.default.removeObserver(self)
    }
}

extension VastPlayerViewController: AdTonosVastPlayerObserver {
    func onAdTonosVastAdsLoaded() {
        statusButton.text = "Single ad is loaded and ready to play"
    }

    func onAdTonosVastError(_ error: AdTonosVastError) {
        statusButton.text = "Error occurred during ads request or any ads interaction like playing, pausing"
    }

    func onAdTonosVastAdsAvabilityExpired() {
        statusButton.text = "Ads expired."
    }

    func onAdTonosVastAdsStarted() {
        statusButton.text = "Sequence of one or more ads in VAST starts to play"
    }

    func onAdTonosVastAdPaused() {
        statusButton.text = "Single ad is paused"
    }

    func onAdTonosVastAdPlayStarted() {
        statusButton.text = "Single ad is played"
    }

    func onAdTonosVastAdsEnded() {
        statusButton.text = "Sequence of one or more VAST ads has ended"
    }
}

